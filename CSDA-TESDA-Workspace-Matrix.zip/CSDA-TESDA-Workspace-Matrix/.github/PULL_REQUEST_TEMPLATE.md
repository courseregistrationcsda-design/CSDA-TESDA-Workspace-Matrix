## What does this PR change?

<!-- Link the issue this closes, e.g. "Closes #12" -->

## How was it tested?

- [ ] `index.html` opens and runs standalone in a browser
- [ ] Month / Week / Day views verified
- [ ] CONSOLE (announcements, cancellation) verified
- [ ] Feedback hub dispatch verified (Formspree + relay)
- [ ] Cross-device behavior verified (second device or private window)
- [ ] No secrets added (PINs, tokens, personal emails)

## Screenshots (if UI changed)
