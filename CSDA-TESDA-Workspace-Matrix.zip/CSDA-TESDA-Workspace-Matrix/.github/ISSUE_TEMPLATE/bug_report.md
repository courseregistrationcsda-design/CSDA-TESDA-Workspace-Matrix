---
name: Bug report
about: Something in the workspace matrix is misbehaving
title: "[bug] "
labels: bug
assignees: ""
---

**Describe the bug**
A clear description of what went wrong.

**Where**
- View: Month / Week / Day / CONSOLE / Date modal / Feedback hub
- Device & browser (e.g. iPhone 13, Safari / Android, Chrome)
- Deployed via: Vercel / GitHub Pages / local file

**Steps to reproduce**
1.
2.
3.

**Expected behavior**
What you expected to happen.

**Screenshots / console output**
If applicable, add screenshots or browser console errors.

**Additional context**
Was a second device involved (relay sync)? Was the CONSOLE unlocked?
